# This Python code was automatically generated from the following Metview Macro:
# /Users/cgr/metview/ctest/convert/test_when.mv
# at: 2023-09-21 20:34:46
# using version: Metview 5.19.2


import metview as mv


v = 2
r = 0
if v == 1:
    r = 1
elif v == 2:
    r = 2

print(r)
