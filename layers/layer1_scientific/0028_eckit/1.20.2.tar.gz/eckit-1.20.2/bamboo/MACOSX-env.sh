export PATH=$HOME/Applications/CMake.app/Contents/bin:$PATH

