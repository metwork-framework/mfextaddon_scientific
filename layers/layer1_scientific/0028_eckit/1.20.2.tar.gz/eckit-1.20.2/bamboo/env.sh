#!/usr/bin/env bash

# export ctest_parallel="no"
export ECKIT_TEST_THREADS=8
